# Sense360 AirIQ (ESPHome) — Modular Packages

This repository provides a modular, production-ready ESPHome layout for the Sense360 AirIQ:
- **Base**: Wi-Fi, encrypted API, OTA, logging, time.
- **Hardware**: ESP32-S3 core, I²C/UART buses, LD2412 hub, hidden WS2812 strip.
- **Features**:
  - **Basic**: minimal public entities (PM2.5/PM10, Temp/Humidity, VOC/NOx, CO₂, Presence). Hidden limit numbers keep the LED logic working without cluttering HA.
  - **Pro**: full SEN5x set, status texts, LD2412 gates & tuning, buttons/switches, ALS, web UI.
- **Factory Overlay (private)**: batch/device calibrations and production-only tweaks.

## Build Profiles
- `configs/airiq/airiq_basic.yaml` – recommended for end users.
- `configs/airiq/airiq_pro.yaml` – power users/diagnostics.
- `*_factory.yaml` – production programming only (includes private overlay).

## Notes
- **GPIO45 (SCL)** is an ESP32-S3 strapping pin; if reliability issues arise, move I²C to non-strapping pins (e.g., `SDA=GPIO39`, `SCL=GPIO40`) in future revisions. Update the `substitutions` accordingly.
- API is **encrypted** and OTA is **password-protected**. Populate `secrets.yaml` before building.
- Avoid committing anything under `packages/overlays_factory_private/`.
